% 原始数据
t=importdata('1024x.txt');x=importdata('1024duibi.txt');
figure ;plot(t,x);xlabel('t(s)');ylabel('amplitude of chest rise and fall');title('raw data');grid on;axis equal;
% 原始信号的频域图
%对信号进行fft变换，获取信号频率分布
L=length(t);   % 采样长度 应该是偶数--1024个点
T=(t(end)-t(1))/length(t); % 采样周期等于采样长度除去采样点数--0.05s一个点
Fs=1/T;   % 采样频率--一秒20下
f=Fs*(0:(L/2))/L;
% 傅里叶变换
S=x(1:L);
Y = fft(S);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
% 
F1=2*f;
figure ; plot(F1,P1)
title('Frequency domain plot of raw chest  signal')
xlabel('f (Hz)')
ylabel('amplitude')
axis([0 3 0 6]) 

% 一次滤波得到y值
fs = 1/0.05;         % 采样频率
f0 = 0.15;            % 中心频率
bw = 0.05;            % 陷波带宽
[b, a] = iirnotch(f0/(fs/2), bw/(fs/2));
% 应用滤波器
y = filter(b, a, x);
% % 绘制结果
% figure ;plot(t, y);
% xlabel('时间 (秒)');
% ylabel('滤波后的信号');
% title('滤波结果');
% % 一次滤波后的图
% %对信号进行fft变换，获取信号频率分布
% L=length(t);   % 采样长度 应该是偶数--1024个点
% T=(t(end)-t(1))/length(t); % 采样周期等于采样长度除去采样点数--0.05s一个点
% Fs=1/T;   % 采样频率--一秒20下
% f1=Fs*(0:(L/2))/L;
% % 傅里叶变换
% S1=y(1:L);
% Y = fft(S1);
% P21 = abs(Y/L);
% P11 = P21(1:L/2+1);
% P11(2:end-1) = 2*P11(2:end-1);
% % 
% F11=2*f1;
% figure ; plot(F11,P11)
% title('Single-Sided Amplitude Spectrum of S(t)')
% xlabel('f (Hz)')
% ylabel('|P1(f)|')
% axis([0 3 0 4]) 

% 二次滤波后的幅度值z
fs = 1/0.05;         % 采样频率
f0 = 0.65;            % 中心频率
bw = 0.05;            % 陷波带宽
[b, a] = iirnotch(f0/(fs/2), bw/(fs/2));
% 应用滤波器
z = filter(b, a, y);
figure ;plot(t, z);
xlabel('t (s)');ylabel('amplitude of chest rise and fall');title('Filtered Signal');axis([0 51.2 180 320]);grid on;
%对信号进行fft变换，获取信号频率分布
L=length(t);   % 采样长度 应该是偶数--1024个点
T=(t(end)-t(1))/length(t); % 采样周期等于采样长度除去采样点数--0.05s一个点
Fs=1/T;   % 采样频率--一秒20下
f12=Fs*(0:(L/2))/L;
% 傅里叶变换
S12=z(1:L);
Y = fft(S12);
P212 = abs(Y/L);
P112 = P212(1:L/2+1);
P112(2:end-1) = 2*P112(2:end-1);
% 
F112=2*f12;
figure ; plot(F112,P112)
title('Filtered signal spectogram')
xlabel('f (Hz)')
ylabel('amplitude')
axis([0 3 0 12]) 



